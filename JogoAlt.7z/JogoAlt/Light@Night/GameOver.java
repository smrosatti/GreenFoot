import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;

public class GameOver extends Actor
{
    private GreenfootImage image;   // the original image
    public static final float FONT_SIZE = 100.0f;
    /**
     * Create a score board with dummy result for testing.
     */
    public GameOver()
    {
        this(100);
    }

    /**
     * Create a score board for the final result.
     */
    public GameOver(int score)
    {
        makeImage("Score: ", score);
    }

    /**
     * Create a score board for the final result.
     */
    public GameOver(String text, int score)
    {
        makeImage("Score: ", score);
    }

    /**
     * Make the score board image.
     */
    private void makeImage(String prefix, int score)
    {
        image = getImage();

        Font font = image.getFont();
        font = font.deriveFont(FONT_SIZE);
        image.setFont(font);
        image.setColor(Color.YELLOW);
        image.drawString(prefix + score, 150, 370);
        setImage(image);
    }
}