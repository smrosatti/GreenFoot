import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LanternBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LanternBug extends Actor
{
    private int imageNumber;
    private int count = 1;
    /**
     * Act - do whatever the LanternBug wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Follow the mouse
        if(Greenfoot.mouseMoved(null)) 
        {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            setLocation(mouse.getX(), mouse.getY());
        } 
        
        changeImage();
        makeDust();
        eatBug();
        consumeMe();
    }

    public void changeImage()
    {
        imageNumber++;
        if (imageNumber == 3) {
            imageNumber = 0;
        }
        setImage("Bug-" + imageNumber + ".png");
    }
    
    private void makeDust()
    {
        count--;
        if (count == 0) 
        {
            getWorld().addObject ( new RedFairyDust(), getX(), getY());
            count = 1;
        }
    }
    
    public void eatBug()
    {
        Night world = (Night)getWorld();
        
        if(canSee(SmallerBug.class))
        {
            eat(SmallerBug.class);
            world.Score();
            Greenfoot.playSound("Twinkeling.wav");
        }
    }
    
     public void consumeMe()
    {
        Night world = (Night)getWorld();
        
        if(canSee(Fire.class))
        {
            world.gameOver();
        }
    }
    
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }
    
    public void eat(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        if(actor != null)
        {
            getWorld().removeObject(actor);
        }
    }
}
