import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Night here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Night extends World
{
    Score score = new Score("Score: ");
    /**
     * Constructor for objects of class Night.
     * 
     */
    public Night()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(760, 460, 1); 
        setPaintOrder(GameOver.class, LanternBug.class, SmallerBug.class, Fire.class, RedFairyDust.class,
        FairyDust.class,Smoke.class);

        prepare();
    }

    public void act()
    {
        if(Greenfoot.getRandomNumber(100) < 2) {
            addObject(new SmallerBug(), Greenfoot.getRandomNumber(760), 450);
            Greenfoot.playSound("score.wav");
        }
        
        if(Greenfoot.getRandomNumber(100) < 1) {
            addObject(new Fire(), Greenfoot.getRandomNumber(760), 0);   
        }
    }

    public void Score()
    {
        score.add(10);
    }
    
    public void gameOver() 
    {
        addObject(new GameOver(score.getValue()), getWidth()/2, getHeight()/2);
        Greenfoot.stop();
        Greenfoot.playSound("gameover.wav");
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        LanternBug lanternbug = new LanternBug();
        addObject(lanternbug, 392, 240);
        
        addObject(score, 85, 25);
    }
}
